"""Unit and integration test suite for CrowdWisdomTrading pipeline."""

import datetime
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

from config.settings import get_config
from data.database import DatabaseManager
from data.pipeline import DataIngestionPipeline
from features.sentiment_analyzer import FinancialSentimentAnalyzer
from features.feature_engineering import FeatureEngineer
from models.metrics import compute_metrics
from models.predictor import NaivePersistenceModel, RidgeSentimentPriceModel, XGBoostMultiHorizonModel


@pytest.fixture
def config():
    return get_config(ticker="TSLA", days_back=30)


@pytest.fixture
def db_manager(tmp_path):
    return DatabaseManager(tmp_path / "test.db")


def test_sentiment_analyzer_lexicon():
    analyzer = FinancialSentimentAnalyzer()
    bullish_res = analyzer.analyze_text("TSLA is looking bullish with a massive breakout and record deliveries beat!")
    bearish_res = analyzer.analyze_text("TSLA is crashing, breakdown below support with SEC probe and margin miss.")

    assert bullish_res["compound"] > 0.4, "Expected strongly positive compound score"
    assert bearish_res["compound"] < -0.4, "Expected strongly negative compound score"


def test_feature_engineering_horizons(config):
    fe = FeatureEngineer(config)
    price_cols, sent_cols = fe.get_feature_columns()

    # Generate small synthetic aligned df
    dates = pd.date_range("2026-01-01", periods=35, freq="B")
    data = []
    base_price = 200.0
    for i, d in enumerate(dates):
        p = base_price + i * 1.5 + np.sin(i) * 3
        data.append({
            "asset": "TSLA",
            "date_str": d.strftime("%Y-%m-%d"),
            "timestamp_utc": d,
            "timestamp_est": d,
            "open": p - 1.0,
            "high": p + 2.0,
            "low": p - 2.0,
            "close": p,
            "volume": 20000000.0,
            "post_volume": 45,
            "sentiment_mean": 0.05,
            "sentiment_std": 0.1,
            "sentiment_weighted_eng": 0.08,
            "sentiment_weighted_kol": 0.07,
            "bull_bear_ratio": 0.2,
            "pos_ratio": 0.5,
            "neg_ratio": 0.3,
            "total_likes": 5000,
            "total_retweets": 1200,
            "total_views": 80000,
        })
    df_aligned = pd.DataFrame(data)
    df_features = fe.build_features(df_aligned)

    for h in [0, 1, 2, 3, 4, 5]:
        assert f"target_price_{h}" in df_features.columns
        assert f"target_return_{h}" in df_features.columns

    # Horizon 0 should nowcast exact current close
    np.testing.assert_allclose(df_features["target_price_0"], df_features["close"])
    np.testing.assert_allclose(df_features["target_return_0"], 0.0)


def test_no_lookahead_bias(config, db_manager):
    pipeline = DataIngestionPipeline(config, db_manager)
    df_prices = pd.DataFrame([
        {"asset": "TSLA", "timestamp_utc": pd.Timestamp("2026-05-01 20:00:00"), "timestamp_est": pd.Timestamp("2026-05-01 16:00:00"), "date_str": "2026-05-01", "open": 200.0, "high": 205.0, "low": 198.0, "close": 202.0, "volume": 1e7},
        {"asset": "TSLA", "timestamp_utc": pd.Timestamp("2026-05-02 20:00:00"), "timestamp_est": pd.Timestamp("2026-05-02 16:00:00"), "date_str": "2026-05-02", "open": 202.0, "high": 208.0, "low": 201.0, "close": 206.0, "volume": 1e7},
    ])
    # Post that arrives AFTER May 1 close (at 17:00 EST on May 1)
    df_tweets = pd.DataFrame([
        {"created_at_est": pd.Timestamp("2026-05-01 14:00:00"), "sentiment_compound": 0.5, "likes": 10, "retweets": 2, "views": 100, "author_followers": 500},
        {"created_at_est": pd.Timestamp("2026-05-01 17:00:00"), "sentiment_compound": -0.8, "likes": 100, "retweets": 20, "views": 1000, "author_followers": 5000},
    ])

    aligned = pipeline.align_tweets_with_prices(df_prices, df_tweets)
    # The post from 17:00 should NOT be included in Bar 1 (2026-05-01 16:00 close)
    assert aligned.iloc[0]["post_volume"] == 1
    assert aligned.iloc[0]["sentiment_mean"] == 0.5
    # It SHOULD be included in Bar 2 (2026-05-02 16:00 close)
    assert aligned.iloc[1]["post_volume"] == 1
    assert aligned.iloc[1]["sentiment_mean"] == -0.8


def test_models_multi_horizon_prediction():
    horizons = [0, 1, 2, 3, 4, 5]
    n_samples = 40
    n_features = 8
    rng = np.random.default_rng(42)

    X = pd.DataFrame(rng.normal(0, 1, (n_samples, n_features)), columns=[f"f_{i}" for i in range(n_features)])
    y = {h: rng.normal(0.001 * h, 0.02, n_samples) for h in horizons}
    base_prices = np.linspace(200, 250, n_samples)

    # Test Ridge
    ridge = RidgeSentimentPriceModel(horizons=horizons, alpha=1.0)
    ridge.fit(X, y)
    preds = ridge.predict_prices(X, base_prices)
    assert len(preds) == 6
    np.testing.assert_allclose(preds[0], base_prices)
    for h in horizons:
        assert (preds[h] > 0).all()

    # Test XGBoost
    xgb = XGBoostMultiHorizonModel(horizons=horizons, n_estimators=10, max_depth=2)
    xgb.fit(X, y)
    preds_xgb = xgb.predict_prices(X, base_prices)
    assert len(preds_xgb) == 6
    np.testing.assert_allclose(preds_xgb[0], base_prices)
    for h in horizons:
        assert (preds_xgb[h] > 0).all()


def test_compute_metrics():
    actual = np.array([101.0, 102.0, 105.0])
    pred = np.array([101.5, 102.5, 104.0])
    base = np.array([100.0, 100.0, 100.0])

    m = compute_metrics(actual, pred, base, horizon=1)
    assert "mae" in m
    assert "rmse" in m
    assert "dir_acc" in m
    assert m["mae"] == round(float(np.mean([0.5, 0.5, 1.0])), 4)
    assert m["dir_acc"] == 100.0  # All predicted in correct direction from 100

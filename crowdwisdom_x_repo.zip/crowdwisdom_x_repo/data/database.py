"""Database schemas and persistence layer for CrowdWisdomTrading pipeline."""

from __future__ import annotations

import datetime
from pathlib import Path
import pandas as pd
from sqlalchemy import (
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    create_engine,
    Index,
)
from sqlalchemy.orm import declarative_base, sessionmaker, scoped_session

Base = declarative_base()


class RawTweet(Base):
    __tablename__ = "raw_tweets"

    id = Column(Integer, primary_key=True, autoincrement=True)
    tweet_id = Column(String(64), unique=True, index=True)
    asset = Column(String(16), index=True)
    created_at_utc = Column(DateTime, index=True)
    created_at_est = Column(DateTime, index=True)
    text = Column(Text)
    likes = Column(Integer, default=0)
    retweets = Column(Integer, default=0)
    replies = Column(Integer, default=0)
    views = Column(Integer, default=0)
    author_followers = Column(Integer, default=0)
    sentiment_compound = Column(Float, default=0.0)
    sentiment_pos = Column(Float, default=0.0)
    sentiment_neg = Column(Float, default=0.0)
    sentiment_neu = Column(Float, default=1.0)


class PriceBar(Base):
    __tablename__ = "raw_prices"

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset = Column(String(16), index=True)
    timestamp_utc = Column(DateTime, index=True)
    timestamp_est = Column(DateTime, index=True)
    date_str = Column(String(16), index=True)
    open = Column(Float)
    high = Column(Float)
    low = Column(Float)
    close = Column(Float)
    volume = Column(Float)


class NewsArticle(Base):
    __tablename__ = "raw_news"

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset = Column(String(16), index=True)
    published_date = Column(DateTime, index=True)
    title = Column(Text)
    url = Column(Text)
    summary = Column(Text)
    sentiment_score = Column(Float, default=0.0)


class PredictionRecord(Base):
    __tablename__ = "model_predictions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset = Column(String(16), index=True)
    model_name = Column(String(64), index=True)
    fold = Column(Integer)
    bar_date = Column(String(16), index=True)
    horizon = Column(Integer)  # 0, 1, 2, 3, 4, 5
    current_price = Column(Float)
    predicted_price = Column(Float)
    actual_price = Column(Float)
    residual = Column(Float)
    predicted_return = Column(Float)
    actual_return = Column(Float)


class DatabaseManager:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine(f"sqlite:///{self.db_path}", echo=False)
        self.session_factory = sessionmaker(bind=self.engine)
        self.Session = scoped_session(self.session_factory)
        self.init_db()

    def init_db(self):
        """Creates tables if they do not exist."""
        Base.metadata.create_all(self.engine)

    def save_dataframe(self, df: pd.DataFrame, table_name: str, if_exists: str = "append"):
        """Saves a dataframe directly into SQLite using pandas."""
        df.to_sql(table_name, self.engine, if_exists=if_exists, index=False)

    def load_dataframe(self, query: str) -> pd.DataFrame:
        """Executes a SQL query and returns a pandas DataFrame."""
        return pd.read_sql_query(query, self.engine)

    def get_tweets_df(self, asset: str) -> pd.DataFrame:
        query = f"SELECT * FROM raw_tweets WHERE asset = '{asset}' ORDER BY created_at_utc ASC"
        df = self.load_dataframe(query)
        if not df.empty:
            df["created_at_utc"] = pd.to_datetime(df["created_at_utc"])
            df["created_at_est"] = pd.to_datetime(df["created_at_est"])
        return df

    def get_prices_df(self, asset: str) -> pd.DataFrame:
        query = f"SELECT * FROM raw_prices WHERE asset = '{asset}' ORDER BY timestamp_utc ASC"
        df = self.load_dataframe(query)
        if not df.empty:
            df["timestamp_utc"] = pd.to_datetime(df["timestamp_utc"])
            df["timestamp_est"] = pd.to_datetime(df["timestamp_est"])
        return df

    def get_news_df(self, asset: str) -> pd.DataFrame:
        query = f"SELECT * FROM raw_news WHERE asset = '{asset}' ORDER BY published_date DESC"
        df = self.load_dataframe(query)
        if not df.empty:
            df["published_date"] = pd.to_datetime(df["published_date"])
        return df

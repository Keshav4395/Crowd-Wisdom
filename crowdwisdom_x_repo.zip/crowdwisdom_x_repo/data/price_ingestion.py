"""Historical price ingestion and UTC/EST timestamp alignment."""

from __future__ import annotations

import datetime
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
import yfinance as yf
from config.settings import Config
from data.database import DatabaseManager


class PriceIngestion:
    def __init__(self, config: Config, db_manager: DatabaseManager):
        self.config = config
        self.db = db_manager
        self.est_tz = ZoneInfo(config.market_tz)
        self.utc_tz = ZoneInfo("UTC")

    def fetch_price_data(self, days_back: int | None = None) -> pd.DataFrame:
        """Fetches daily OHLCV prices from yfinance and aligns UTC and EST timestamps."""
        days = days_back or self.config.days_back
        ticker_str = self.config.ticker
        print(f"[PriceIngestion] Fetching {days} days of price data for {ticker_str}...")

        # Request with slightly wider window to guarantee full 180 trading bars
        ticker = yf.Ticker(ticker_str)
        period_arg = f"{int(days * 1.5)}d"
        hist = ticker.history(period=period_arg, interval="1d")

        if hist.empty:
            raise RuntimeError(f"Failed to fetch price data for {ticker_str}")

        # Keep the most recent `days` trading sessions
        hist = hist.tail(days).copy()

        # Handle timezone formatting
        records = []
        for idx_ts, row in hist.iterrows():
            # idx_ts is timestamp from yfinance (localized to US/Eastern or naive)
            if idx_ts.tzinfo is None:
                ts_est = idx_ts.replace(hour=16, minute=0, second=0, tzinfo=self.est_tz)
            else:
                ts_est = idx_ts.tz_convert(self.est_tz).replace(hour=16, minute=0, second=0)

            ts_utc = ts_est.astimezone(self.utc_tz)
            date_str = ts_est.strftime("%Y-%m-%d")

            records.append({
                "asset": ticker_str,
                "timestamp_utc": ts_utc.replace(tzinfo=None),
                "timestamp_est": ts_est.replace(tzinfo=None),
                "date_str": date_str,
                "open": float(row["Open"]),
                "high": float(row["High"]),
                "low": float(row["Low"]),
                "close": float(row["Close"]),
                "volume": float(row["Volume"]),
            })

        df_prices = pd.DataFrame(records)
        df_prices = df_prices.sort_values("timestamp_utc").reset_index(drop=True)

        # Persist to database
        self.db.save_dataframe(df_prices, "raw_prices", if_exists="replace")
        print(
            f"[PriceIngestion] Stored {len(df_prices)} bars for {ticker_str} "
            f"({df_prices['date_str'].iloc[0]} to {df_prices['date_str'].iloc[-1]})"
        )
        return df_prices

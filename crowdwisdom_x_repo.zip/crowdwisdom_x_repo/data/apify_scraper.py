"""Apify-based X (Twitter) scraper and simulation fallback engine.

Ingests posts for the chosen asset over the last 180 days with cashtags,
tickers, engagement metrics (likes, reposts, views), and author follower counts.
Performs exact UTC and EST timestamp conversions and sentiment scoring.
"""

from __future__ import annotations

import datetime
import os
from datetime import timedelta
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from config.settings import Config
from data.database import DatabaseManager

try:
    from apify_client import ApifyClient
except ImportError:
    ApifyClient = None


class ApifyTweetScraper:
    def __init__(self, config: Config, db_manager: DatabaseManager):
        self.config = config
        self.db = db_manager
        self.vader = SentimentIntensityAnalyzer()
        self.est_tz = ZoneInfo(config.market_tz)
        self.utc_tz = ZoneInfo("UTC")
        self.client = ApifyClient(config.apify_token) if (ApifyClient and config.apify_token) else None

    def scrape_tweets(
        self,
        days_back: int | None = None,
        start_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
    ) -> pd.DataFrame:
        """Scrapes X posts using Apify actor or realistic fallback engine."""
        days = days_back or self.config.days_back
        ticker = self.config.ticker
        cashtags = self.config.cashtags

        print(f"[ApifyScraper] Initiating X scraping for {ticker}...")
        posts = []

        if self.client:
            try:
                print(f"[ApifyScraper] Authenticated with Apify. Launching Actor '{self.config.apify_actor_id}'...")
                if start_dt:
                    start_date_str = start_dt.strftime("%Y-%m-%d")
                else:
                    start_date_str = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)).strftime("%Y-%m-%d")
                
                run_input = {
                    "searchTerms": cashtags + [f"{ticker} stock", f"{ticker} price"],
                    "maxTweets": 3000,
                    "sort": "Top",
                    "since": start_date_str,
                    "language": "en",
                }
                run = self.client.actor(self.config.apify_actor_id).call(
                    run_input=run_input,
                    run_timeout=timedelta(seconds=300),
                    wait_duration=timedelta(seconds=300),
                )
                if run is None:
                    raise RuntimeError("Apify actor run returned no result")
                dataset_items = list(self.client.dataset(run.default_dataset_id).iterate_items())
                print(f"[ApifyScraper] Retrieved {len(dataset_items)} posts from Apify.")

                for item in dataset_items:
                    text = item.get("text") or item.get("full_text") or ""
                    if not text:
                        continue
                    
                    # Parse timestamp
                    created_at_str = item.get("createdAt") or item.get("created_at")
                    if created_at_str:
                        dt = pd.to_datetime(created_at_str)
                        if dt.tzinfo is None:
                            ts_utc = dt.replace(tzinfo=self.utc_tz)
                        else:
                            ts_utc = dt.astimezone(self.utc_tz)
                    else:
                        ts_utc = datetime.datetime.now(datetime.timezone.utc)
                    
                    ts_est = ts_utc.astimezone(self.est_tz)

                    author = item.get("author") or item.get("user") or {}
                    followers = author.get("followers") or author.get("followers_count") or 100

                    # Sentiment
                    vader_scores = self.vader.polarity_scores(text)

                    posts.append({
                        "asset": ticker,
                        "tweet_id": str(item.get("id") or item.get("id_str") or hash(text)),
                        "created_at_utc": ts_utc.replace(tzinfo=None),
                        "created_at_est": ts_est.replace(tzinfo=None),
                        "text": text,
                        "likes": int(item.get("likeCount") or item.get("favorite_count") or 0),
                        "retweets": int(item.get("retweetCount") or item.get("retweet_count") or 0),
                        "replies": int(item.get("replyCount") or item.get("reply_count") or 0),
                        "views": int(item.get("viewCount") or 0),
                        "author_followers": int(followers),
                        "sentiment_compound": float(vader_scores["compound"]),
                        "sentiment_pos": float(vader_scores["pos"]),
                        "sentiment_neg": float(vader_scores["neg"]),
                        "sentiment_neu": float(vader_scores["neu"]),
                    })
            except Exception as e:
                print(f"[ApifyScraper] Apify run failed or timed out ({e}). Engaging high-fidelity simulation engine.")
                posts = []

        if not posts:
            if os.getenv("REQUIRE_LIVE_DATA", "").strip().lower() in ("1", "true", "yes"):
                raise RuntimeError(
                    "REQUIRE_LIVE_DATA is set but no live X posts were retrieved from Apify. "
                    "Check APIFY_API_TOKEN, Apify credits, and the error printed above."
                )
            print("=" * 70)
            print("[ApifyScraper] WARNING: USING SIMULATED X DATA (not live tweets).")
            print("[ApifyScraper] Sentiment features and all downstream results are simulated.")
            print("=" * 70)
            posts = self._simulate_180d_x_stream(days=days, start_dt=start_dt, end_dt=end_dt)

        df_tweets = pd.DataFrame(posts)
        # Drop duplicates by tweet_id if any
        df_tweets = df_tweets.drop_duplicates(subset=["tweet_id"]).sort_values("created_at_utc").reset_index(drop=True)

        self.db.save_dataframe(df_tweets, "raw_tweets", if_exists="replace")
        print(f"[ApifyScraper] Stored {len(df_tweets)} X posts in database.")
        return df_tweets

    def _simulate_180d_x_stream(
        self,
        days: int = 180,
        start_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
    ) -> list[dict]:
        """Generates a high-fidelity tweet stream mirroring real market sentiment."""
        ticker = self.config.ticker
        rng = np.random.default_rng(seed=42)

        if end_dt is None:
            end_anchor = datetime.datetime.now(datetime.timezone.utc)
        else:
            end_anchor = end_dt.replace(tzinfo=datetime.timezone.utc) if end_dt.tzinfo is None else end_dt

        if start_dt is None:
            total_days = days
            start_anchor = end_anchor - datetime.timedelta(days=days)
        else:
            start_anchor = start_dt.replace(tzinfo=datetime.timezone.utc) if start_dt.tzinfo is None else start_dt
            total_days = max(days, (end_anchor - start_anchor).days + 1)

        print(f"[ApifyScraper] Generating realistic X dataset for {ticker} from {start_anchor.date()} to {end_anchor.date()} ({total_days} days)...")

        bullish_templates = [
            r"${TICKER} looking insanely strong here! Breakout above key resistance on heavy volume 🚀",
            r"Massive call buying spotted on ${TICKER} ahead of delivery numbers. Smart money accumulating.",
            r"Energy storage margins for ${TICKER} are skyrocketing. Street is sleeping on the Megapack moat.",
            r"FSD version 13 is mind-blowing. End-to-end neural nets represent a step function change for ${TICKER}.",
            r"Wedbush analyst reiterates Outperform on ${TICKER}, raises price target to $350. Top AI idea.",
            r"Retail bears are about to get squeezed hard on ${TICKER}. Look at the borrow fees ticking up!",
            r"${TICKER} Cybercab event confirmed my thesis. Commercial autonomous robotaxi fleet by 2026.",
            r"Strong Q3 deliveries beat consensus! Auto gross margin excluding regulatory credits stabilized. Bullish ${TICKER}!",
            r"Added to my long position on ${TICKER}. Long-term risk/reward is exceptional at these levels.",
            r"${TICKER} AI compute cluster expansion is outpacing competitors. Dojo + Nvidia H100 clusters.",
        ]

        bearish_templates = [
            r"${TICKER} demand softness in Europe is becoming obvious. Expecting another round of price cuts.",
            r"NHTSA scrutiny on ${TICKER} autonomous claims is a major headline risk. Taking some off the table.",
            r"Valuation on ${TICKER} is completely disconnected from automotive fundamentals. P/E > 70 is unsustainable.",
            r"Competitors in China (BYD, Xiaomi) are eating ${TICKER}'s lunch in the mass market segment.",
            r"Technical breakdown on ${TICKER} below the 50-day moving average. Head and shoulders pattern forming.",
            r"Bearish put volume surging in ${TICKER} weeklies. Hedging downside risk here.",
            r"${TICKER} robotaxi timeline pushed back again. Overpromising and underdelivering.",
            r"Auto gross margins continue to compress. Price war is taking its toll on ${TICKER}.",
            r"Insider selling reported at ${TICKER}. Not a great look into the upcoming earnings report.",
            r"Macro headwinds and high financing rates are slowing high-ticket EV purchases. Cautious on ${TICKER}.",
        ]

        neutral_templates = [
            r"${TICKER} consolidating right around the 200-day EMA. Waiting for a decisive directional trigger.",
            r"Options implied volatility on ${TICKER} is elevated ahead of earnings. Straddle implies an 8% move.",
            r"Morgan Stanley notes ${TICKER} valuation is a tale of two businesses: core auto vs embodied AI.",
            r"${TICKER} traded 45M shares today, right in line with the 30-day average. Neutral volume profile.",
            r"Watching the $210 support level on ${TICKER}. If that holds, we range trade between $210 and $235.",
            r"Fed interest rate decision today will dictate liquidity for high-beta growth stocks like ${TICKER}.",
            r"${TICKER} quarterly update upcoming. Key metrics to watch: automotive gross margin and energy growth.",
            r"Comparing ${TICKER} vs Mag7 performance this quarter: laggard in Q1, recovering in Q3.",
        ]

        posts = []
        tweet_counter = 100000

        # Create time series of sentiment regimes (simulating market cycles over the period)
        t_steps = np.linspace(0, 4 * np.pi, total_days)
        sentiment_cycle = 0.25 * np.sin(t_steps) + 0.15 * np.cos(0.5 * t_steps)

        for d in range(total_days):
            date_anchor = start_anchor + datetime.timedelta(days=d)
            day_regime = sentiment_cycle[d] + rng.normal(0, 0.1)

            # 30 to 60 tweets per day sampled across different times of day
            num_tweets_today = rng.integers(30, 60)
            
            # Probability distribution of sentiment today based on regime
            p_bull = np.clip(0.42 + day_regime * 0.4, 0.15, 0.75)
            p_bear = np.clip(0.35 - day_regime * 0.3, 0.15, 0.65)
            p_neu = max(0.10, 1.0 - (p_bull + p_bear))
            total_p = p_bull + p_bear + p_neu
            probs = [p_bull / total_p, p_bear / total_p, p_neu / total_p]

            for _ in range(num_tweets_today):
                tweet_counter += 1
                
                # Hour distribution: peak between 9 AM and 5 PM EST
                est_hour = int(np.clip(rng.normal(13, 4), 0, 23))
                minute = rng.integers(0, 60)
                second = rng.integers(0, 60)

                dt_est = date_anchor.replace(hour=est_hour, minute=minute, second=second, tzinfo=self.est_tz)
                dt_utc = dt_est.astimezone(self.utc_tz)

                # Pick sentiment class
                category = rng.choice(["bull", "bear", "neu"], p=probs)
                if category == "bull":
                    raw_text = rng.choice(bullish_templates).replace("{TICKER}", ticker)
                elif category == "bear":
                    raw_text = rng.choice(bearish_templates).replace("{TICKER}", ticker)
                else:
                    raw_text = rng.choice(neutral_templates).replace("{TICKER}", ticker)

                # Author followers: lognormal distribution (mostly 200-5000, occasionally 50k-1M)
                followers = int(np.exp(rng.normal(8.0, 1.8)))
                followers = max(25, min(followers, 2_500_000))

                # Engagement correlates with followers and sentiment intensity
                is_viral = rng.random() < 0.05
                base_engagement_factor = (followers ** 0.35) * (15 if is_viral else 1.0)
                
                likes = int(rng.exponential(scale=base_engagement_factor * 2.5))
                retweets = int(likes * rng.uniform(0.1, 0.35))
                replies = int(likes * rng.uniform(0.05, 0.25))
                views = int(likes * rng.uniform(15.0, 70.0) + followers * 0.2)

                # VADER scoring
                vader_scores = self.vader.polarity_scores(raw_text)

                posts.append({
                    "asset": ticker,
                    "tweet_id": f"x_{ticker}_{tweet_counter}_{d}",
                    "created_at_utc": dt_utc.replace(tzinfo=None),
                    "created_at_est": dt_est.replace(tzinfo=None),
                    "text": raw_text,
                    "likes": likes,
                    "retweets": retweets,
                    "replies": replies,
                    "views": views,
                    "author_followers": followers,
                    "sentiment_compound": float(vader_scores["compound"]),
                    "sentiment_pos": float(vader_scores["pos"]),
                    "sentiment_neg": float(vader_scores["neg"]),
                    "sentiment_neu": float(vader_scores["neu"]),
                })

        return posts

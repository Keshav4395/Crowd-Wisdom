"""Unified data ingestion and alignment pipeline.

Orchestrates price fetching, X scraping, Tavily news ingestion,
and strict EST market-close window alignment to prevent look-ahead bias.
"""

from __future__ import annotations

import datetime
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from config.settings import Config
from data.database import DatabaseManager
from data.price_ingestion import PriceIngestion
from data.apify_scraper import ApifyTweetScraper
from data.news_ingestion import NewsIngestion


class DataIngestionPipeline:
    def __init__(self, config: Config, db_manager: DatabaseManager | None = None):
        self.config = config
        self.db = db_manager or DatabaseManager(config.db_path)
        self.price_ingestor = PriceIngestion(self.config, self.db)
        self.x_scraper = ApifyTweetScraper(self.config, self.db)
        self.news_ingestor = NewsIngestion(self.config, self.db)

    def run(self, force_refresh: bool = False) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Runs the complete ingestion pipeline: prices, tweets, news, and aligned dataset."""
        print("=" * 70)
        print(f"[DataIngestionPipeline] Starting ingestion for {self.config.ticker} ({self.config.days_back} days)...")
        print("=" * 70)

        # 1. Fetch Prices
        df_prices = self.price_ingestor.fetch_price_data()

        # 2. Scrape X Tweets covering the exact price bar window (plus 2 days buffer)
        start_dt = df_prices["timestamp_utc"].min() - pd.Timedelta(days=2)
        end_dt = df_prices["timestamp_utc"].max() + pd.Timedelta(days=1)
        df_tweets = self.x_scraper.scrape_tweets(start_dt=start_dt, end_dt=end_dt)

        # 3. Fetch News
        df_news = self.news_ingestor.fetch_recent_news()

        # 4. Strict Alignment (EST 16:00 close to close)
        df_aligned = self.align_tweets_with_prices(df_prices, df_tweets)

        # Persist aligned dataset
        self.db.save_dataframe(df_aligned, "aligned_dataset", if_exists="replace")
        print(f"[DataIngestionPipeline] Successfully built aligned dataset with {len(df_aligned)} trading bars.")
        return df_prices, df_tweets, df_news, df_aligned

    def align_tweets_with_prices(self, df_prices: pd.DataFrame, df_tweets: pd.DataFrame) -> pd.DataFrame:
        """Aligns X posts into distinct price bar windows [t_prev_close, t_curr_close].
        
        Guarantees zero look-ahead bias: each price bar at day t only sees posts
        arriving up to 16:00 EST on day t.
        """
        print("[DataIngestionPipeline] Aligning X tweets to price bars with EST cutoff...")
        df_prices = df_prices.sort_values("timestamp_est").reset_index(drop=True)
        df_tweets = df_tweets.sort_values("created_at_est").reset_index(drop=True)

        aligned_rows = []

        for i in range(len(df_prices)):
            curr_bar = df_prices.iloc[i]
            curr_close_est = curr_bar["timestamp_est"]

            if i == 0:
                # For first bar, take tweets up to 1 day prior
                prev_close_est = curr_close_est - pd.Timedelta(days=1)
            else:
                prev_close_est = df_prices.iloc[i - 1]["timestamp_est"]

            # Filter tweets within [prev_close_est, curr_close_est]
            mask = (df_tweets["created_at_est"] > prev_close_est) & (df_tweets["created_at_est"] <= curr_close_est)
            window_tweets = df_tweets.loc[mask]

            if not window_tweets.empty:
                post_vol = len(window_tweets)
                sent_compounds = window_tweets["sentiment_compound"].values
                likes = window_tweets["likes"].values
                rts = window_tweets["retweets"].values
                views = window_tweets["views"].values
                followers = window_tweets["author_followers"].values

                # Mean sentiment
                sent_mean = float(np.mean(sent_compounds))
                sent_std = float(np.std(sent_compounds)) if len(sent_compounds) > 1 else 0.0

                # Engagement-weighted sentiment
                eng_weights = np.log1p(likes + 2.0 * rts + 0.1 * views)
                sum_eng = np.sum(eng_weights)
                if sum_eng > 0:
                    sent_weighted_eng = float(np.sum(sent_compounds * eng_weights) / sum_eng)
                else:
                    sent_weighted_eng = sent_mean

                # Follower/KOL-weighted sentiment
                kol_weights = np.log1p(followers)
                sum_kol = np.sum(kol_weights)
                if sum_kol > 0:
                    sent_weighted_kol = float(np.sum(sent_compounds * kol_weights) / sum_kol)
                else:
                    sent_weighted_kol = sent_mean

                # Bull / Bear proportions
                n_bull = np.sum(sent_compounds > 0.05)
                n_bear = np.sum(sent_compounds < -0.05)
                bull_bear_ratio = float((n_bull - n_bear) / (n_bull + n_bear + 1.0))
                pos_ratio = float(n_bull / post_vol)
                neg_ratio = float(n_bear / post_vol)

                tot_likes = int(np.sum(likes))
                tot_rts = int(np.sum(rts))
                tot_views = int(np.sum(views))
            else:
                # Missing/gap fallback
                post_vol = 0
                sent_mean = 0.0
                sent_std = 0.0
                sent_weighted_eng = 0.0
                sent_weighted_kol = 0.0
                bull_bear_ratio = 0.0
                pos_ratio = 0.0
                neg_ratio = 0.0
                tot_likes = 0
                tot_rts = 0
                tot_views = 0

            aligned_rows.append({
                "asset": curr_bar["asset"],
                "date_str": curr_bar["date_str"],
                "timestamp_utc": curr_bar["timestamp_utc"],
                "timestamp_est": curr_bar["timestamp_est"],
                "open": curr_bar["open"],
                "high": curr_bar["high"],
                "low": curr_bar["low"],
                "close": curr_bar["close"],
                "volume": curr_bar["volume"],
                "post_volume": post_vol,
                "sentiment_mean": sent_mean,
                "sentiment_std": sent_std,
                "sentiment_weighted_eng": sent_weighted_eng,
                "sentiment_weighted_kol": sent_weighted_kol,
                "bull_bear_ratio": bull_bear_ratio,
                "pos_ratio": pos_ratio,
                "neg_ratio": neg_ratio,
                "total_likes": tot_likes,
                "total_retweets": tot_rts,
                "total_views": tot_views,
            })

        df_aligned = pd.DataFrame(aligned_rows)
        return df_aligned

"""Exa.ai neural search ingestion client for alternative X (Twitter) sentiment.

Supports semantic neural querying of X posts and high-engagement discussion threads.
"""

from __future__ import annotations

import datetime
import os
import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from config.settings import Config
from data.database import DatabaseManager

try:
    from exa_py import Exa
except ImportError:
    Exa = None


class ExaTweetScraper:
    """Alternative data scraper using Exa.ai neural embeddings search."""

    def __init__(self, config: Config, db_manager: DatabaseManager):
        self.config = config
        self.db = db_manager
        self.api_key = os.getenv("EXA_API_KEY", "") or None
        self.client = Exa(api_key=self.api_key) if (Exa and self.api_key) else None
        self.vader = SentimentIntensityAnalyzer()

    def search_tweets(self, query: str | None = None, num_results: int = 50) -> pd.DataFrame:
        """Searches X posts via Exa.ai neural search API."""
        ticker = self.config.ticker
        search_query = query or f"${ticker} stock sentiment earnings high engagement tweet analysis"
        posts = []

        if self.client:
            try:
                print(f"[ExaScraper] Querying Exa.ai neural search for: '{search_query}'...")
                response = self.client.search_and_contents(
                    query=search_query,
                    type="neural",
                    use_autoprompt=True,
                    num_results=num_results,
                    include_domains=["twitter.com", "x.com"],
                )
                for item in response.results:
                    text = item.text or ""
                    sentiment = self.vader.polarity_scores(text)
                    pub_date = item.published_date or datetime.datetime.now(datetime.timezone.utc).isoformat()
                    posts.append({
                        "asset": ticker,
                        "tweet_id": f"exa_{item.id}",
                        "created_at_utc": pd.to_datetime(pub_date).tz_localize(None),
                        "created_at_est": pd.to_datetime(pub_date).tz_localize(None),
                        "text": text[:500],
                        "likes": 50,
                        "retweets": 10,
                        "replies": 5,
                        "views": 2500,
                        "author_followers": 1000,
                        "sentiment_compound": float(sentiment["compound"]),
                        "sentiment_pos": float(sentiment["pos"]),
                        "sentiment_neg": float(sentiment["neg"]),
                        "sentiment_neu": float(sentiment["neu"]),
                    })
                print(f"[ExaScraper] Retrieved {len(posts)} posts via Exa.ai.")
            except Exception as e:
                print(f"[ExaScraper] Exa API call encountered exception: {e}")

        df = pd.DataFrame(posts)
        return df

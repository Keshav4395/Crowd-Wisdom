"""Visual Matrix Output Generator.

Produces publication-quality quantitative charts visualizing X sentiment
dynamics against asset price, lead-lag relationships, forecast fan cones,
and walk-forward out-of-sample metrics.
"""

from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import pandas as pd
import seaborn as sns
from config.settings import Config


class VisualMatrixGenerator:
    def __init__(self, config: Config):
        self.config = config
        self.charts_dir = config.charts_dir
        self.charts_dir.mkdir(parents=True, exist_ok=True)
        # Apply standard clean financial styling
        plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")

    def generate_all_charts(
        self,
        df_aligned: pd.DataFrame,
        df_features: pd.DataFrame,
        summary_metrics: pd.DataFrame,
        df_predictions: pd.DataFrame,
        latest_predictions: dict[int, float] | None = None,
    ) -> list[Path]:
        """Generates the full suite of visual matrix charts and returns their filepaths."""
        print("[VisualMatrixGenerator] Generating publication-quality chart suite...")
        saved_paths = []

        saved_paths.append(self.plot_price_sentiment_dual(df_aligned))
        saved_paths.append(self.plot_lead_lag_cross_correlation(df_features))
        saved_paths.append(self.plot_forecast_fan(df_aligned, df_predictions, latest_predictions))
        saved_paths.append(self.plot_walk_forward_performance(summary_metrics))
        saved_paths.append(self.plot_feature_importance(df_features))
        saved_paths.append(self.plot_master_dashboard(df_aligned, df_features, summary_metrics, latest_predictions))

        print(f"[VisualMatrixGenerator] Successfully created {len(saved_paths)} charts in {self.charts_dir}")
        return saved_paths

    def plot_price_sentiment_dual(self, df_aligned: pd.DataFrame) -> Path:
        """Dual-axis time series: Asset Price vs X Engagement-Weighted Sentiment."""
        df = df_aligned.copy()
        df["date"] = pd.to_datetime(df["date_str"])
        df["sent_ema7"] = df["sentiment_weighted_eng"].ewm(span=7, adjust=False).mean()

        fig, (ax1, ax3) = plt.subplots(
            2, 1, figsize=(14, 8), sharex=True, gridspec_kw={"height_ratios": [3, 1]}
        )

        ticker = self.config.ticker
        color_price = "#1f77b4"
        color_sent = "#2ca02c"
        color_sent_neg = "#d62728"

        # Price line
        ax1.plot(df["date"], df["close"], color=color_price, linewidth=2.2, label=f"{ticker} Close Price ($)")
        ax1.set_ylabel(f"{ticker} Price ($)", color=color_price, fontsize=12, fontweight="bold")
        ax1.tick_params(axis="y", labelcolor=color_price)
        ax1.grid(True, linestyle="--", alpha=0.5)

        # Secondary y-axis for Sentiment
        ax2 = ax1.twinx()
        ax2.plot(df["date"], df["sentiment_weighted_eng"], color="#7f7f7f", alpha=0.35, linewidth=1.0, label="Daily X Sentiment (Eng. Weighted)")
        ax2.plot(df["date"], df["sent_ema7"], color="#ff7f0e", linewidth=2.0, label="Sentiment 7-day EMA")
        ax2.axhline(0, color="black", linestyle=":", alpha=0.6)
        
        # Shade positive/negative sentiment regimes
        ax2.fill_between(df["date"], 0, df["sent_ema7"], where=(df["sent_ema7"] >= 0), color=color_sent, alpha=0.15, interpolate=True)
        ax2.fill_between(df["date"], 0, df["sent_ema7"], where=(df["sent_ema7"] < 0), color=color_sent_neg, alpha=0.15, interpolate=True)
        ax2.set_ylabel("X (Twitter) Sentiment Score", color="#ff7f0e", fontsize=12, fontweight="bold")
        ax2.tick_params(axis="y", labelcolor="#ff7f0e")

        # Title and legends
        ax1.set_title(f"CrowdWisdomTrading: {ticker} Price vs X Sentiment Dynamics (180 Days)", fontsize=14, fontweight="bold", pad=12)
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left", framealpha=0.9)

        # Bottom subplot: Post Volume & Engagement
        ax3.bar(df["date"], df["post_volume"], color="#4b6584", alpha=0.7, width=1.0, label="Daily X Post Volume")
        ax3.set_ylabel("Post Volume", fontsize=10, fontweight="bold")
        ax3.set_xlabel("Date (EST Aligned)", fontsize=11, fontweight="bold")
        ax3.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
        ax3.xaxis.set_major_locator(mdates.MonthLocator())
        ax3.legend(loc="upper left")
        ax3.grid(True, linestyle="--", alpha=0.5)

        plt.tight_layout()
        output_path = self.charts_dir / "visual_matrix_price_sentiment_dual.png"
        fig.savefig(output_path, dpi=300)
        plt.close(fig)
        return output_path

    def plot_lead_lag_cross_correlation(self, df_features: pd.DataFrame) -> Path:
        """Lead-Lag Cross-Correlation between lagged sentiment and forward price returns."""
        df = df_features.copy()
        sent = df["sentiment_weighted_eng"]
        ret = df["ret_1d"]

        lags = range(-10, 11)
        corrs = []
        for lag in lags:
            if lag < 0:
                # Price leads sentiment (sentiment is lagged)
                c = ret.iloc[:lag].corr(sent.iloc[-lag:])
            elif lag > 0:
                # Sentiment leads price by `lag` days
                c = sent.iloc[:-lag].corr(ret.iloc[lag:])
            else:
                c = sent.corr(ret)
            corrs.append(c if not np.isnan(c) else 0.0)

        fig, ax = plt.subplots(figsize=(11, 5.5))
        colors = ["#2ca02c" if (k > 0 and v > 0) else "#1f77b4" if k == 0 else "#4b6584" for k, v in zip(lags, corrs)]
        bars = ax.bar(lags, corrs, color=colors, width=0.65, edgecolor="black", alpha=0.85)

        ax.axhline(0, color="black", linestyle="-", linewidth=0.8)
        ax.set_xticks(list(lags))
        ax.set_xlabel("Lag k (Days): [Negative: Price Leads | Positive: X Sentiment Leads Price]", fontsize=11, fontweight="bold")
        ax.set_ylabel("Pearson Correlation", fontsize=11, fontweight="bold")
        ax.set_title(f"Empirical Lead-Lag Cross-Correlation: Sentiment(t - k) vs Price Return(t) for {self.config.ticker}", fontsize=13, fontweight="bold", pad=12)
        ax.grid(True, linestyle="--", alpha=0.5)

        # Highlight predictive horizon
        for bar, lag, val in zip(bars, lags, corrs):
            if lag in [1, 2, 3]:
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + (0.01 if val >= 0 else -0.02), f"{val:.3f}", ha="center", va="bottom", fontsize=9, fontweight="bold", color="#1b5e20")

        plt.tight_layout()
        output_path = self.charts_dir / "visual_matrix_lead_lag_cross_correlation.png"
        fig.savefig(output_path, dpi=300)
        plt.close(fig)
        return output_path

    def plot_forecast_fan(
        self,
        df_aligned: pd.DataFrame,
        df_predictions: pd.DataFrame,
        latest_predictions: dict[int, float] | None = None,
    ) -> Path:
        """Multi-horizon forecast fan chart showing trajectory at n+0, n+1, ..., n+5."""
        df = df_aligned.tail(25).copy()
        ticker = self.config.ticker
        last_date = pd.to_datetime(df["date_str"].iloc[-1])
        anchor_price = float(df["close"].iloc[-1])

        # Forecast horizons
        horizons = self.config.forecast_horizons
        forecast_dates = [last_date + pd.Timedelta(days=h) for h in horizons]

        if latest_predictions:
            forecast_prices = [latest_predictions.get(h, anchor_price) for h in horizons]
        else:
            # Fallback to last predictions in df_predictions for ensemble
            sub = df_predictions[df_predictions["model_name"] == "QuantEnsemble"]
            if not sub.empty:
                last_bar_date = sub["bar_date"].iloc[-1]
                bar_sub = sub[sub["bar_date"] == last_bar_date].sort_values("horizon")
                forecast_prices = bar_sub["predicted_price"].tolist()
            else:
                forecast_prices = [anchor_price * (1 + 0.003 * h) for h in horizons]

        # Calculate residual standard deviation from out-of-sample test
        sub_err = df_predictions[df_predictions["model_name"] == "QuantEnsemble"]
        sigma_h = {}
        for h in horizons:
            errs = sub_err[sub_err["horizon"] == h]["residual"] if not sub_err.empty else pd.Series([2.0 * (h + 1)])
            sigma_h[h] = float(errs.std()) if len(errs) > 1 and not np.isnan(errs.std()) else (anchor_price * 0.015 * np.sqrt(max(h, 1)))

        upper_1s = [p + 1.0 * sigma_h[h] for h, p in zip(horizons, forecast_prices)]
        lower_1s = [p - 1.0 * sigma_h[h] for h, p in zip(horizons, forecast_prices)]
        upper_2s = [p + 2.0 * sigma_h[h] for h, p in zip(horizons, forecast_prices)]
        lower_2s = [p - 2.0 * sigma_h[h] for h, p in zip(horizons, forecast_prices)]

        fig, ax = plt.subplots(figsize=(12, 6.5))

        # Historical price
        hist_dates = pd.to_datetime(df["date_str"])
        ax.plot(hist_dates, df["close"], color="#2c3e50", linewidth=2.5, marker="o", markersize=4, label=f"Historical {ticker} Price")

        # Forecast line
        ax.plot(forecast_dates, forecast_prices, color="#e67e22", linewidth=2.8, marker="s", markersize=6, linestyle="--", label="Quant Forecast (n+0 to n+5)")
        
        # Confidence fan
        ax.fill_between(forecast_dates, lower_1s, upper_1s, color="#f39c12", alpha=0.30, label="68% Confidence Cone (±1σ)")
        ax.fill_between(forecast_dates, lower_2s, upper_2s, color="#f39c12", alpha=0.15, label="95% Confidence Cone (±2σ)")

        # Anchor marker
        ax.scatter([last_date], [anchor_price], color="#c0392b", s=120, zorder=5, label=f"Current Anchor P_n (${anchor_price:.2f})")

        # Annotate forecast values
        for d, p, h in zip(forecast_dates, forecast_prices, horizons):
            pct_chg = ((p - anchor_price) / anchor_price) * 100.0
            sign = "+" if pct_chg >= 0 else ""
            ax.annotate(
                f"n+{h}: ${p:.2f}\n({sign}{pct_chg:.2f}%)",
                (d, p),
                textcoords="offset points",
                xytext=(0, 12 if pct_chg >= 0 else -25),
                ha="center",
                fontsize=8.5,
                fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.2", facecolor="white", edgecolor="#e67e22", alpha=0.85)
            )

        ax.set_title(f"CrowdWisdomTrading: Multi-Horizon Predictive Price Fan (n+0 to n+5) for {ticker}", fontsize=13, fontweight="bold", pad=12)
        ax.set_ylabel(f"{ticker} Price ($)", fontsize=11, fontweight="bold")
        ax.set_xlabel("Date", fontsize=11, fontweight="bold")
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))
        ax.grid(True, linestyle="--", alpha=0.5)
        ax.legend(loc="upper left", framealpha=0.9)

        plt.tight_layout()
        output_path = self.charts_dir / "visual_matrix_forecast_fan.png"
        fig.savefig(output_path, dpi=300)
        plt.close(fig)
        return output_path

    def plot_walk_forward_performance(self, summary_metrics: pd.DataFrame) -> Path:
        """Visual comparison of Out-of-Sample metrics across models and horizons."""
        df = summary_metrics[summary_metrics["horizon"] > 0].copy()

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        palette = {
            "NaivePersistence": "#95a5a6",
            "PriceOnly_Ridge": "#3498db",
            "Ridge_SentimentPrice": "#9b59b6",
            "XGBoost_SentimentPrice": "#e74c3c",
            "QuantEnsemble": "#2ecc71",
        }

        # Plot 1: MAE ($ error) across horizons
        sns.barplot(data=df, x="horizon", y="mae", hue="model", palette=palette, ax=ax1, edgecolor="black")
        ax1.set_title("Out-of-Sample Price MAE ($) by Forecast Horizon", fontsize=12, fontweight="bold")
        ax1.set_xlabel("Horizon (n + h)", fontsize=11, fontweight="bold")
        ax1.set_ylabel("Mean Absolute Error ($)", fontsize=11, fontweight="bold")
        ax1.grid(True, linestyle="--", alpha=0.5)
        ax1.legend(title="Model", framealpha=0.9)

        # Plot 2: Directional Accuracy (Hit Rate %) across horizons
        sns.barplot(data=df, x="horizon", y="dir_acc", hue="model", palette=palette, ax=ax2, edgecolor="black")
        ax2.axhline(50.0, color="black", linestyle="--", linewidth=1.0, label="50% Coin Toss Baseline")
        ax2.set_title("Out-of-Sample Directional Hit Rate (%) by Horizon", fontsize=12, fontweight="bold")
        ax2.set_xlabel("Horizon (n + h)", fontsize=11, fontweight="bold")
        ax2.set_ylabel("Directional Accuracy (%)", fontsize=11, fontweight="bold")
        ax2.set_ylim(40, 70)
        ax2.grid(True, linestyle="--", alpha=0.5)
        ax2.legend(title="Model", framealpha=0.9)

        plt.suptitle(f"Walk-Forward Out-of-Sample Validation Matrix ({self.config.n_splits} Folds, Embargoed)", fontsize=14, fontweight="bold")
        plt.tight_layout()
        output_path = self.charts_dir / "visual_matrix_walk_forward_performance.png"
        fig.savefig(output_path, dpi=300)
        plt.close(fig)
        return output_path

    def plot_feature_importance(self, df_features: pd.DataFrame) -> Path:
        """Visualizes the top predictive feature contributions from Price vs Sentiment."""
        from features.feature_engineering import FeatureEngineer
        from xgboost import XGBRegressor

        price_cols, sent_cols = FeatureEngineer.get_feature_columns()
        all_cols = [c for c in (price_cols + sent_cols) if c in df_features.columns]
        
        df_valid = df_features.dropna(subset=["target_return_3"]).reset_index(drop=True)
        X = df_valid[all_cols].fillna(0)
        y = df_valid["target_return_3"].values

        model = XGBRegressor(n_estimators=50, max_depth=3, random_state=42, verbosity=0)
        model.fit(X, y)

        importances = pd.Series(model.feature_importances_, index=all_cols).sort_values(ascending=False).head(15)

        fig, ax = plt.subplots(figsize=(11, 6))
        colors = ["#2ca02c" if feat in sent_cols else "#1f77b4" for feat in importances.index]
        bars = ax.barh(importances.index[::-1], importances.values[::-1], color=colors[::-1], edgecolor="black", alpha=0.85)

        ax.set_title(f"XGBoost Feature Importance: Price (Blue) vs X Sentiment (Green) [Horizon n+3]", fontsize=13, fontweight="bold", pad=12)
        ax.set_xlabel("Relative Predictive Importance (Gini Gain)", fontsize=11, fontweight="bold")
        ax.grid(True, linestyle="--", alpha=0.5)

        # Custom legend
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor="#1f77b4", edgecolor="black", label="Price-Only Features"),
            Patch(facecolor="#2ca02c", edgecolor="black", label="X Sentiment Features"),
        ]
        ax.legend(handles=legend_elements, loc="lower right", framealpha=0.9)

        plt.tight_layout()
        output_path = self.charts_dir / "visual_matrix_feature_importance.png"
        fig.savefig(output_path, dpi=300)
        plt.close(fig)
        return output_path

    def plot_master_dashboard(
        self,
        df_aligned: pd.DataFrame,
        df_features: pd.DataFrame,
        summary_metrics: pd.DataFrame,
        latest_predictions: dict[int, float] | None = None,
    ) -> Path:
        """Master 4-quadrant visual matrix combining all core analytics into one high-res chart."""
        fig = plt.figure(figsize=(18, 12))
        gs = fig.add_gridspec(2, 2, hspace=0.28, wspace=0.22)

        ticker = self.config.ticker
        df = df_aligned.copy()
        df["date"] = pd.to_datetime(df["date_str"])
        df["sent_ema7"] = df["sentiment_weighted_eng"].ewm(span=7, adjust=False).mean()

        # Quadrant 1: Price vs Sentiment Trajectory
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.plot(df["date"], df["close"], color="#1f77b4", linewidth=2.0, label="Price ($)")
        ax1.set_ylabel("Price ($)", color="#1f77b4", fontweight="bold")
        ax1.tick_params(axis="y", labelcolor="#1f77b4")
        ax1_twin = ax1.twinx()
        ax1_twin.plot(df["date"], df["sent_ema7"], color="#ff7f0e", linewidth=1.8, label="Sentiment 7d EMA")
        ax1_twin.axhline(0, color="black", linestyle=":", alpha=0.5)
        ax1_twin.set_ylabel("X Sentiment", color="#ff7f0e", fontweight="bold")
        ax1.set_title(f"(A) {ticker} Price vs X Sentiment Trajectory", fontsize=12, fontweight="bold")
        ax1.grid(True, linestyle="--", alpha=0.5)

        # Quadrant 2: Lead-Lag Cross Correlation
        ax2 = fig.add_subplot(gs[0, 1])
        sent = df_features["sentiment_weighted_eng"]
        ret = df_features["ret_1d"]
        lags = list(range(-5, 6))
        corrs = []
        for lag in lags:
            if lag < 0:
                c = ret.iloc[:lag].corr(sent.iloc[-lag:])
            elif lag > 0:
                c = sent.iloc[:-lag].corr(ret.iloc[lag:])
            else:
                c = sent.corr(ret)
            corrs.append(c if not np.isnan(c) else 0.0)
        c_colors = ["#2ca02c" if k > 0 else "#4b6584" for k in lags]
        ax2.bar(lags, corrs, color=c_colors, width=0.6, edgecolor="black")
        ax2.axhline(0, color="black", linewidth=0.8)
        ax2.set_xlabel("Lag k (Days) [k > 0: Sentiment Leads Price]", fontweight="bold")
        ax2.set_ylabel("Correlation with Return", fontweight="bold")
        ax2.set_title("(B) Sentiment Lead-Lag Alpha Structure", fontsize=12, fontweight="bold")
        ax2.grid(True, linestyle="--", alpha=0.5)

        # Quadrant 3: Multi-Horizon Forecast Fan
        ax3 = fig.add_subplot(gs[1, 0])
        recent_df = df.tail(15)
        anchor_p = float(recent_df["close"].iloc[-1])
        last_d = pd.to_datetime(recent_df["date_str"].iloc[-1])
        horizons = self.config.forecast_horizons
        f_dates = [last_d + pd.Timedelta(days=h) for h in horizons]
        f_prices = [latest_predictions.get(h, anchor_p) for h in horizons] if latest_predictions else [anchor_p * (1 + 0.003 * h) for h in horizons]
        ax3.plot(pd.to_datetime(recent_df["date_str"]), recent_df["close"], color="#2c3e50", marker="o", linewidth=2.0, label="Recent Actual")
        ax3.plot(f_dates, f_prices, color="#e67e22", marker="s", linewidth=2.5, linestyle="--", label="Forecast (n+0 to n+5)")
        ax3.scatter([last_d], [anchor_p], color="#c0392b", s=100, zorder=5)
        ax3.set_title(f"(C) Multi-Horizon Forecast Cone (Anchor: ${anchor_p:.2f})", fontsize=12, fontweight="bold")
        ax3.set_ylabel("Price ($)", fontweight="bold")
        ax3.grid(True, linestyle="--", alpha=0.5)
        ax3.legend(loc="upper left")

        # Quadrant 4: Walk-Forward Out-of-Sample Hit Rate Matrix
        ax4 = fig.add_subplot(gs[1, 1])
        sub_m = summary_metrics[summary_metrics["horizon"] > 0]
        sns.barplot(data=sub_m, x="horizon", y="dir_acc", hue="model", ax=ax4, edgecolor="black")
        ax4.axhline(50.0, color="black", linestyle="--", label="50% Coin Toss")
        ax4.set_ylim(42, 68)
        ax4.set_title("(D) Out-of-Sample Directional Hit Rate (%) by Horizon", fontsize=12, fontweight="bold")
        ax4.set_xlabel("Horizon (n + h)", fontweight="bold")
        ax4.set_ylabel("Hit Rate (%)", fontweight="bold")
        ax4.grid(True, linestyle="--", alpha=0.5)
        ax4.legend(title="Model", loc="lower right", framealpha=0.9, fontsize=8)

        fig.suptitle(f"CrowdWisdomTrading: Master Visual Matrix Dashboard for {ticker}", fontsize=16, fontweight="bold", y=0.99)
        plt.tight_layout()
        output_path = self.charts_dir / "visual_matrix_comprehensive_dashboard.png"
        fig.savefig(output_path, dpi=300)
        plt.close(fig)
        return output_path

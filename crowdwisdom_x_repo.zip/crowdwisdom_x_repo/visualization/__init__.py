"""Visualization package for CrowdWisdomTrading charts."""

from .visual_matrix import VisualMatrixGenerator

__all__ = ["VisualMatrixGenerator"]

"""Configuration module for CrowdWisdomTrading X Sentiment Price Prediction.

Handles environment loading, asset metadata, Apify actor configurations,
feature engineering constants, model parameters, and database paths.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from dotenv import load_dotenv

# Load local .env if present
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent


@dataclass
class Config:
    # Asset Configuration
    ticker: str = os.getenv("ASSET_TICKER", "TSLA")
    asset_name: str = os.getenv("ASSET_NAME", "Tesla")
    cashtags: list[str] = field(default_factory=lambda: ["$TSLA", "#TSLA"])
    keywords: list[str] = field(
        default_factory=lambda: ["TSLA", "Tesla", "Elon Musk", "Robotaxi", "Cybertruck", "FSD"]
    )
    days_back: int = int(os.getenv("DAYS_BACK", "180"))
    market_tz: str = os.getenv("TIMEZONE", "America/New_York")
    market_close_hour_est: int = 16  # 4:00 PM EST daily cutoff

    # API Keys & Service Config
    apify_token: str | None = os.getenv("APIFY_API_TOKEN", "") or None
    apify_actor_id: str = "apidojo/tweet-scraper"  # High-reliability Apify Twitter Scraper
    tavily_api_key: str | None = os.getenv("TAVILY_API_KEY", "") or None

    # Database
    db_path: Path = BASE_DIR / "data" / "crowd_wisdom.db"
    db_uri: str = f"sqlite:///{BASE_DIR / 'data' / 'crowd_wisdom.db'}"

    # Target Forecasting Horizons
    forecast_horizons: list[int] = field(default_factory=lambda: [0, 1, 2, 3, 4, 5])

    # Validation Setup
    n_splits: int = 5
    test_size_ratio: float = 0.12
    embargo_periods: int = 5  # Purge/embargo to prevent multi-step target leakage

    # Output Paths
    output_dir: Path = BASE_DIR / "output"
    charts_dir: Path = BASE_DIR / "output" / "charts"
    reports_dir: Path = BASE_DIR / "output" / "reports"

    def __post_init__(self):
        self.charts_dir.mkdir(parents=True, exist_ok=True)
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)


def get_config(**kwargs) -> Config:
    return Config(**kwargs)

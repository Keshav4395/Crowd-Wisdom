"""Master CLI Execution Script for CrowdWisdomTrading Pipeline.

Executes end-to-end data ingestion, quantitative feature engineering,
walk-forward cross-validation, multi-horizon price forecasting (n+0 to n+5),
visual matrix chart generation, and 1-page sentiment outlook reporting.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
import pandas as pd

from config.settings import Config, get_config
from data.database import DatabaseManager
from data.pipeline import DataIngestionPipeline
from features.feature_engineering import FeatureEngineer
from models.walk_forward import WalkForwardValidator
from models.predictor import QuantEnsembleModel, XGBoostMultiHorizonModel
from visualization.visual_matrix import VisualMatrixGenerator
from reports.sentiment_summary import SentimentSummaryGenerator


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="CrowdWisdomTrading: X Sentiment Multi-Horizon Price Prediction Pipeline"
    )
    parser.add_argument("--ticker", type=str, default="TSLA", help="Asset ticker symbol (default: TSLA)")
    parser.add_argument("--days", type=int, default=180, help="Lookback window in days (default: 180)")
    parser.add_argument("--force-refresh", action="store_true", help="Force re-fetching from sources")
    return parser.parse_args()


def main():
    args = parse_args()
    config = get_config(ticker=args.ticker, days_back=args.days)
    db = DatabaseManager(config.db_path)

    print("\n" + "=" * 78)
    print("  CrowdWisdomTrading: X Sentiment Multi-Horizon Price Prediction Pipeline  ")
    print(f"  Asset: {config.ticker} | Horizon: n+0, n+1, n+2, n+3, n+4, n+5 | Lookback: {config.days_back}d  ")
    print("=" * 78 + "\n")

    # Step 1: Ingestion & Alignment
    pipeline = DataIngestionPipeline(config, db)
    df_prices, df_tweets, df_news, df_aligned = pipeline.run(force_refresh=args.force_refresh)

    # Step 2: Quantitative Feature Engineering (Sentiment & Price ONLY)
    print("\n[Pipeline Step 2] Engineering time-series features from sentiment and price only...")
    fe = FeatureEngineer(config)
    df_features = fe.build_features(df_aligned)
    p_cols, s_cols = fe.get_feature_columns()
    print(f"[Pipeline Step 2] Created {len(p_cols)} price features and {len(s_cols)} sentiment features across {len(df_features)} bars.")

    # Step 3: Walk-Forward Validation & Performance Evaluation
    print("\n[Pipeline Step 3] Executing 5-Fold Walk-Forward Validation (with embargoing)...")
    validator = WalkForwardValidator(config, db)
    df_fold_m, summary_metrics, df_predictions = validator.run_validation(df_features)

    # Step 4: Fit Full Model to Generate Forward Forecasts (n+0 to n+5)
    print("\n[Pipeline Step 4] Fitting full dataset model to generate current forward forecasts...")
    all_feature_cols = [c for c in (p_cols + s_cols) if c in df_features.columns]
    
    # Train on all rows that have target_price_5 defined
    valid_train = df_features.dropna(subset=["target_price_5"]).copy()
    X_full = valid_train[all_feature_cols]
    y_full = {h: valid_train[f"target_return_{h}"].values for h in config.forecast_horizons}

    prod_model = QuantEnsembleModel(horizons=config.forecast_horizons)
    prod_model.fit(X_full, y_full)

    # The current bar is the very last available row in df_features
    latest_feat_row = df_features.iloc[[-1]][all_feature_cols]
    current_anchor_price = float(df_features.iloc[-1]["close"])
    current_anchor_date = df_features.iloc[-1]["date_str"]

    latest_pred_prices = prod_model.predict_prices(latest_feat_row, np.array([current_anchor_price]))
    latest_forecasts = {h: float(latest_pred_prices[h][0]) for h in config.forecast_horizons}

    # Step 5: Visual Matrix Output Generator
    print("\n[Pipeline Step 5] Generating Visual Matrix Output Charts...")
    vis = VisualMatrixGenerator(config)
    chart_paths = vis.generate_all_charts(
        df_aligned=df_aligned,
        df_features=df_features,
        summary_metrics=summary_metrics,
        df_predictions=df_predictions,
        latest_predictions=latest_forecasts,
    )

    # Step 6: Quantitative Financial Backtest (Sharpe, Sortino, Max Drawdown)
    print("\n[Pipeline Step 6] Executing Portfolio Backtest & Risk-Adjusted Evaluation...")
    from models.backtest import QuantitativeBacktester
    backtester = QuantitativeBacktester(config)
    df_equity, backtest_metrics = backtester.run_backtest(df_predictions, horizon=1)
    equity_chart_path = backtester.plot_backtest_equity_curves(df_equity)
    chart_paths.append(equity_chart_path)

    # Step 7: 1-Page Sentiment Outlook Report
    print("\n[Pipeline Step 7] Generating 1-Page Sentiment Outlook Report...")
    reporter = SentimentSummaryGenerator(config, db)
    report_path = reporter.generate_report(
        df_aligned=df_aligned,
        df_features=df_features,
        df_news=df_news,
        latest_predictions=latest_forecasts,
        summary_metrics=summary_metrics,
    )

    # Step 8: Formal Evaluation Report (Markdown & PDF)
    print("\n[Pipeline Step 8] Generating Comprehensive Evaluation Report (Markdown & PDF)...")
    from reports.evaluation_report import EvaluationReportGenerator
    eval_gen = EvaluationReportGenerator(config)
    eval_md_path, eval_pdf_path = eval_gen.generate_evaluation_report(
        backtest_metrics=backtest_metrics,
        walk_forward_metrics=summary_metrics,
        equity_chart_path=equity_chart_path,
    )

    # Step 9: Print Executive Terminal Summary
    print("\n" + "=" * 78)
    print(f"  MULTI-HORIZON FORECAST MATRIX: {config.ticker} (Anchor: ${current_anchor_price:.2f} at {current_anchor_date})  ")
    print("=" * 78)
    print(f"{'Horizon':<10} {'Target Date':<14} {'Forecast ($)':<15} {'Expected Ret (%)':<18} {'Signal':<15}")
    print("-" * 78)
    anchor_dt = pd.to_datetime(current_anchor_date)
    for h in config.forecast_horizons:
        f_date = (anchor_dt + pd.Timedelta(days=h)).strftime("%Y-%m-%d")
        f_price = latest_forecasts[h]
        ret_pct = ((f_price - current_anchor_price) / current_anchor_price) * 100.0
        sig = "ANCHOR" if h == 0 else "BUY / LONG" if ret_pct > 0.75 else "SELL / SHORT" if ret_pct < -0.75 else "NEUTRAL"
        print(f"n+{h:<7} {f_date:<14} ${f_price:<14.2f} {ret_pct:>+7.2f}%            {sig:<15}")
    print("=" * 78)

    print("\n" + "=" * 78)
    print(f"  FINANCIAL RISK-ADJUSTED EVALUATION MATRIX ({config.ticker} Out-of-Sample)  ")
    print("=" * 78)
    print(f"{'Strategy / Model':<24} {'Sharpe':<10} {'Sortino':<10} {'Max DD (%)':<12} {'Win Rate':<10}")
    print("-" * 78)
    for m_name, m_stats in backtest_metrics.items():
        clean_name = m_name.replace("_", " ")[:22]
        sh = f"{m_stats.get('sharpe_ratio', 0.0):+.2f}"
        so = f"{m_stats.get('sortino_ratio', 0.0):+.2f}"
        dd = f"{m_stats.get('max_drawdown_pct', 0.0):.1f}%"
        wr = f"{m_stats.get('win_rate_pct', 0.0):.1f}%"
        print(f"{clean_name:<24} {sh:<10} {so:<10} {dd:<12} {wr:<10}")
    print("=" * 78)

    print("\n[Pipeline Summary]")
    print(f"• Database Path:          {config.db_path}")
    print(f"• 1-Page Sentiment Note:  {report_path}")
    print(f"• Evaluation Report (MD): {eval_md_path}")
    print(f"• Evaluation Report (PDF):{eval_pdf_path}")
    print(f"• Generated Charts:       {len(chart_paths)} PNG charts in {config.charts_dir}")
    for p in chart_paths:
        print(f"   - {p.name}")
    print("\nPipeline completed successfully!\n")


if __name__ == "__main__":
    import numpy as np
    main()

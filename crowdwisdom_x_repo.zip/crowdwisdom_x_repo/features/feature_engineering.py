"""Quantitative Feature Engineering from sentiment and price only.

Constructs stationary price features, social engagement-weighted sentiment features,
momentum, divergence, and multi-horizon target labels (n+0 through n+5).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from config.settings import Config


class FeatureEngineer:
    def __init__(self, config: Config):
        self.config = config
        self.horizons = config.forecast_horizons  # [0, 1, 2, 3, 4, 5]

    def build_features(self, df_aligned: pd.DataFrame) -> pd.DataFrame:
        """Transforms raw aligned price and sentiment bars into a full quantitative feature matrix."""
        df = df_aligned.copy()
        df = df.sort_values("timestamp_est").reset_index(drop=True)

        # ---------------------------------------------------------
        # 1. Price-Derived Features (Stationary & Scale-Invariant)
        # ---------------------------------------------------------
        close = df["close"].values
        high = df["high"].values
        low = df["low"].values
        volume = df["volume"].values

        # Log returns over multiple lookback windows
        df["ret_1d"] = pd.Series(np.log(close / np.roll(close, 1)), index=df.index)
        df["ret_2d"] = pd.Series(np.log(close / np.roll(close, 2)), index=df.index)
        df["ret_3d"] = pd.Series(np.log(close / np.roll(close, 3)), index=df.index)
        df["ret_5d"] = pd.Series(np.log(close / np.roll(close, 5)), index=df.index)
        df["ret_10d"] = pd.Series(np.log(close / np.roll(close, 10)), index=df.index)

        # Realized Volatility
        df["realized_vol_5d"] = df["ret_1d"].rolling(window=5, min_periods=5).std() * np.sqrt(252)
        df["realized_vol_10d"] = df["ret_1d"].rolling(window=10, min_periods=10).std() * np.sqrt(252)

        # High-Low Range Normalized by Close
        df["hl_spread"] = (high - low) / np.maximum(close, 1e-6)

        # Moving Average Ratios
        sma_5 = df["close"].rolling(window=5, min_periods=5).mean()
        sma_20 = df["close"].rolling(window=20, min_periods=20).mean()
        df["price_to_sma5"] = (df["close"] / sma_5) - 1.0
        df["price_to_sma20"] = (df["close"] / sma_20) - 1.0

        # Bollinger Band %b proxy
        rolling_std_20 = df["close"].rolling(window=20, min_periods=20).std()
        df["bollinger_z"] = (df["close"] - sma_20) / (rolling_std_20 + 1e-6)

        # Price RSI (14-day)
        delta = df["close"].diff()
        gain = (delta.where(delta > 0, 0.0)).rolling(window=14, min_periods=14).mean()
        loss = (-delta.where(delta < 0, 0.0)).rolling(window=14, min_periods=14).mean()
        rs = gain / (loss + 1e-6)
        df["rsi_14"] = 100.0 - (100.0 / (1.0 + rs))
        df["rsi_14_norm"] = (df["rsi_14"] - 50.0) / 50.0  # Normalized to [-1, 1]

        # Volume Z-score
        vol_mean_20 = df["volume"].rolling(window=20, min_periods=20).mean()
        vol_std_20 = df["volume"].rolling(window=20, min_periods=20).std()
        df["volume_zscore"] = (df["volume"] - vol_mean_20) / (vol_std_20 + 1e-6)

        # ---------------------------------------------------------
        # 2. Sentiment-Derived Features
        # ---------------------------------------------------------
        # Attention Burst Score (Social Volume Z-score)
        post_mean_20 = df["post_volume"].rolling(window=20, min_periods=20).mean()
        post_std_20 = df["post_volume"].rolling(window=20, min_periods=20).std()
        df["post_vol_zscore"] = (df["post_volume"] - post_mean_20) / (post_std_20 + 1e-6)

        # Rolling Sentiment EMAs
        sent_series = df["sentiment_weighted_eng"]
        df["sentiment_ema_3"] = sent_series.ewm(span=3, adjust=False).mean()
        df["sentiment_ema_7"] = sent_series.ewm(span=7, adjust=False).mean()
        df["sentiment_ema_14"] = sent_series.ewm(span=14, adjust=False).mean()

        # Sentiment Momentum & Velocity
        df["sentiment_momentum"] = sent_series - df["sentiment_ema_7"]
        df["sentiment_velocity"] = sent_series - sent_series.shift(1)
        df["sentiment_acceleration"] = df["sentiment_velocity"] - df["sentiment_velocity"].shift(1)

        # Key Opinion Leader vs Retail Sentiment Spread
        df["kol_retail_spread"] = df["sentiment_weighted_kol"] - df["sentiment_mean"]

        # Sentiment-Price Divergence Feature
        # When sentiment is bullish (+1) but price returns are negative (-1), divergence is positive
        price_ret_sign = np.sign(df["ret_5d"].fillna(0))
        sent_mom_sign = np.sign(df["sentiment_momentum"].fillna(0))
        df["sentiment_price_divergence"] = sent_mom_sign - price_ret_sign

        # ---------------------------------------------------------
        # 3. Time / Calendar Features
        # ---------------------------------------------------------
        ts_est = pd.to_datetime(df["timestamp_est"])
        dow = ts_est.dt.dayofweek
        df["dow_sin"] = np.sin(2 * np.pi * dow / 5.0)
        df["dow_cos"] = np.cos(2 * np.pi * dow / 5.0)
        month = ts_est.dt.month
        df["month_sin"] = np.sin(2 * np.pi * month / 12.0)
        df["month_cos"] = np.cos(2 * np.pi * month / 12.0)

        # ---------------------------------------------------------
        # 4. Multi-Horizon Future Targets (n+0, n+1, ..., n+5)
        # ---------------------------------------------------------
        # For each horizon h:
        # target_price_h: actual closing price at n+h
        # target_return_h: ln(P_{n+h} / P_n)
        for h in self.horizons:
            if h == 0:
                # Horizon 0 is nowcast at n
                df[f"target_price_{h}"] = df["close"]
                df[f"target_return_{h}"] = 0.0
            else:
                df[f"target_price_{h}"] = df["close"].shift(-h)
                df[f"target_return_{h}"] = np.log(df[f"target_price_{h}"] / df["close"])

        # Drop warm-up rows where 20-day rolling indicators are NaN
        # (Preserve rows that have valid targets or valid features)
        warmup_cutoff = 20
        df_valid = df.iloc[warmup_cutoff:].copy().reset_index(drop=True)

        return df_valid

    @staticmethod
    def get_feature_columns() -> tuple[list[str], list[str]]:
        """Returns lists of price feature names and sentiment feature names."""
        price_features = [
            "ret_1d",
            "ret_2d",
            "ret_3d",
            "ret_5d",
            "ret_10d",
            "realized_vol_5d",
            "realized_vol_10d",
            "hl_spread",
            "price_to_sma5",
            "price_to_sma20",
            "bollinger_z",
            "rsi_14_norm",
            "volume_zscore",
            "dow_sin",
            "dow_cos",
            "month_sin",
            "month_cos",
        ]

        sentiment_features = [
            "sentiment_mean",
            "sentiment_std",
            "sentiment_weighted_eng",
            "sentiment_weighted_kol",
            "bull_bear_ratio",
            "pos_ratio",
            "neg_ratio",
            "post_vol_zscore",
            "sentiment_ema_3",
            "sentiment_ema_7",
            "sentiment_ema_14",
            "sentiment_momentum",
            "sentiment_velocity",
            "sentiment_acceleration",
            "kol_retail_spread",
            "sentiment_price_divergence",
        ]

        return price_features, sentiment_features

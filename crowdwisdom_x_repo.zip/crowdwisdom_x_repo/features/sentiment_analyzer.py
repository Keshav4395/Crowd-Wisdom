"""Financial sentiment analysis engine with domain-specific lexicon adaptations."""

from __future__ import annotations

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


class FinancialSentimentAnalyzer:
    """Enhances VADER with financial and crypto/equity market terminology."""

    FINANCIAL_LEXICON = {
        # Bullish terms
        "bull": 2.0,
        "bullish": 2.5,
        "breakout": 2.2,
        "squeeze": 2.0,
        "all-time-high": 2.8,
        "ath": 2.5,
        "moon": 2.0,
        "beat": 2.0,
        "outperform": 2.2,
        "accumulating": 1.8,
        "upgrade": 2.2,
        "long": 1.5,
        "calls": 1.6,
        "rocket": 2.0,
        "surging": 2.2,
        "record": 1.8,
        # Bearish terms
        "bear": -2.0,
        "bearish": -2.5,
        "dump": -2.5,
        "crash": -3.0,
        "breakdown": -2.2,
        "downgrade": -2.2,
        "miss": -2.0,
        "underperform": -2.0,
        "dilution": -2.4,
        "puts": -1.6,
        "short": -1.8,
        "probe": -2.2,
        "investigation": -2.0,
        "lawsuit": -2.0,
        "plunge": -2.5,
        "overvalued": -2.0,
    }

    def __init__(self):
        self.vader = SentimentIntensityAnalyzer()
        # Update lexicon with domain-specific terms
        self.vader.lexicon.update(self.FINANCIAL_LEXICON)

    def analyze_text(self, text: str) -> dict[str, float]:
        """Calculates polarity scores (compound, pos, neg, neu)."""
        if not text or not text.strip():
            return {"compound": 0.0, "pos": 0.0, "neg": 0.0, "neu": 1.0}
        return self.vader.polarity_scores(text)

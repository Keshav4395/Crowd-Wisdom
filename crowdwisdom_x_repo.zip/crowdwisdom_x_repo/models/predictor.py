"""Predictive models for multi-horizon price forecasting (n+0 through n+5).

Supports Naive Persistence, Price-Only Baseline, Regularized Ridge,
XGBoost Gradient Boosting, and Quant Ensemble.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor


class BaseMultiHorizonModel:
    def __init__(self, name: str, horizons: list[int] = [0, 1, 2, 3, 4, 5]):
        self.name = name
        self.horizons = horizons
        self.is_fitted = False

    def fit(self, X: pd.DataFrame, y_returns: dict[int, np.ndarray]):
        raise NotImplementedError

    def predict_returns(self, X: pd.DataFrame) -> dict[int, np.ndarray]:
        raise NotImplementedError

    def predict_prices(self, X: pd.DataFrame, base_prices: np.ndarray | pd.Series) -> dict[int, np.ndarray]:
        """Recovers predicted price levels P_{n+h} from base price P_n and predicted log return."""
        base_p = np.asarray(base_prices, dtype=float)
        pred_returns = self.predict_returns(X)
        pred_prices = {}

        for h in self.horizons:
            if h == 0:
                pred_prices[h] = base_p.copy()
            else:
                pred_prices[h] = base_p * np.exp(pred_returns[h])
        return pred_prices


class NaivePersistenceModel(BaseMultiHorizonModel):
    """Predicts no change: P_{n+h} = P_n (random walk baseline)."""

    def __init__(self, horizons: list[int] = [0, 1, 2, 3, 4, 5]):
        super().__init__("NaivePersistence", horizons)

    def fit(self, X: pd.DataFrame, y_returns: dict[int, np.ndarray]):
        self.is_fitted = True
        return self

    def predict_returns(self, X: pd.DataFrame) -> dict[int, np.ndarray]:
        n_samples = len(X)
        return {h: np.zeros(n_samples) for h in self.horizons}


class RidgeSentimentPriceModel(BaseMultiHorizonModel):
    """L2-Regularized linear regression with standardized features."""

    def __init__(self, horizons: list[int] = [0, 1, 2, 3, 4, 5], alpha: float = 1.0, feature_subset: list[str] | None = None, name: str = "Ridge"):
        super().__init__(name, horizons)
        self.alpha = alpha
        self.feature_subset = feature_subset
        self.models: dict[int, Ridge] = {}
        self.scalers: dict[int, StandardScaler] = {}

    def fit(self, X: pd.DataFrame, y_returns: dict[int, np.ndarray]):
        features = X[self.feature_subset] if self.feature_subset else X
        for h in self.horizons:
            if h == 0:
                continue
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(features.fillna(0))
            y_h = y_returns[h]

            model = Ridge(alpha=self.alpha, random_state=42)
            model.fit(X_scaled, y_h)

            self.models[h] = model
            self.scalers[h] = scaler
        self.is_fitted = True
        return self

    def predict_returns(self, X: pd.DataFrame) -> dict[int, np.ndarray]:
        features = X[self.feature_subset] if self.feature_subset else X
        n_samples = len(X)
        preds = {}
        for h in self.horizons:
            if h == 0:
                preds[h] = np.zeros(n_samples)
            else:
                scaler = self.scalers[h]
                X_scaled = scaler.transform(features.fillna(0))
                preds[h] = self.models[h].predict(X_scaled)
        return preds


class XGBoostMultiHorizonModel(BaseMultiHorizonModel):
    """Gradient boosted decision trees for non-linear sentiment & price dynamics."""

    def __init__(
        self,
        horizons: list[int] = [0, 1, 2, 3, 4, 5],
        n_estimators: int = 40,
        max_depth: int = 3,
        learning_rate: float = 0.05,
        subsample: float = 0.8,
        colsample_bytree: float = 0.8,
        reg_alpha: float = 0.5,
        reg_lambda: float = 1.0,
        name: str = "XGBoost",
    ):
        super().__init__(name, horizons)
        self.params = {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "learning_rate": learning_rate,
            "subsample": subsample,
            "colsample_bytree": colsample_bytree,
            "reg_alpha": reg_alpha,
            "reg_lambda": reg_lambda,
            "random_state": 42,
            "verbosity": 0,
        }
        self.models: dict[int, XGBRegressor] = {}
        self.feature_names: list[str] = []

    def fit(self, X: pd.DataFrame, y_returns: dict[int, np.ndarray]):
        self.feature_names = list(X.columns)
        for h in self.horizons:
            if h == 0:
                continue
            model = XGBRegressor(**self.params)
            model.fit(X.fillna(0), y_returns[h])
            self.models[h] = model
        self.is_fitted = True
        return self

    def predict_returns(self, X: pd.DataFrame) -> dict[int, np.ndarray]:
        n_samples = len(X)
        preds = {}
        for h in self.horizons:
            if h == 0:
                preds[h] = np.zeros(n_samples)
            else:
                preds[h] = self.models[h].predict(X.fillna(0))
        return preds

    def get_feature_importances(self, horizon: int = 1) -> pd.Series:
        """Returns sorted feature importances for a given horizon."""
        if horizon not in self.models:
            return pd.Series(dtype=float)
        importances = self.models[horizon].feature_importances_
        return pd.Series(importances, index=self.feature_names).sort_values(ascending=False)


class QuantEnsembleModel(BaseMultiHorizonModel):
    """Combines Ridge and XGBoost with variance-reducing weighting."""

    def __init__(
        self,
        horizons: list[int] = [0, 1, 2, 3, 4, 5],
        ridge_weight: float = 0.4,
        xgb_weight: float = 0.6,
    ):
        super().__init__("QuantEnsemble", horizons)
        self.ridge = RidgeSentimentPriceModel(horizons=horizons, alpha=2.0)
        self.xgb = XGBoostMultiHorizonModel(horizons=horizons, n_estimators=45, max_depth=3)
        self.w_ridge = ridge_weight
        self.w_xgb = xgb_weight

    def fit(self, X: pd.DataFrame, y_returns: dict[int, np.ndarray]):
        self.ridge.fit(X, y_returns)
        self.xgb.fit(X, y_returns)
        self.is_fitted = True
        return self

    def predict_returns(self, X: pd.DataFrame) -> dict[int, np.ndarray]:
        r_ridge = self.ridge.predict_returns(X)
        r_xgb = self.xgb.predict_returns(X)
        preds = {}
        for h in self.horizons:
            if h == 0:
                preds[h] = np.zeros(len(X))
            else:
                preds[h] = self.w_ridge * r_ridge[h] + self.w_xgb * r_xgb[h]
        return preds

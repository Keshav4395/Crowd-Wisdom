"""Walk-Forward Cross-Validation engine with purging and embargoing."""

from __future__ import annotations

import numpy as np
import pandas as pd
from config.settings import Config
from data.database import DatabaseManager, PredictionRecord
from features.feature_engineering import FeatureEngineer
from models.metrics import compute_metrics
from models.predictor import (
    BaseMultiHorizonModel,
    NaivePersistenceModel,
    RidgeSentimentPriceModel,
    XGBoostMultiHorizonModel,
    QuantEnsembleModel,
)


class WalkForwardValidator:
    def __init__(self, config: Config, db_manager: DatabaseManager):
        self.config = config
        self.db = db_manager
        self.horizons = config.forecast_horizons
        self.n_splits = config.n_splits
        self.embargo = config.embargo_periods

    def run_validation(self, df_features: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
        """Executes expanding-window walk-forward validation across all models and horizons."""
        print("=" * 70)
        print(f"[WalkForwardValidator] Running {self.n_splits}-fold walk-forward validation...")
        print("=" * 70)

        price_cols, sent_cols = FeatureEngineer.get_feature_columns()
        all_feature_cols = [c for c in (price_cols + sent_cols) if c in df_features.columns]
        price_only_cols = [c for c in price_cols if c in df_features.columns]

        # Ensure valid targets exist up to max horizon
        max_h = max(self.horizons)
        # Valid rows where target_price_5 is not NaN
        df_valid = df_features.dropna(subset=[f"target_price_{max_h}"]).reset_index(drop=True)
        N = len(df_valid)

        if N < 50:
            raise ValueError(f"Insufficient valid data points ({N}) for {self.n_splits}-fold walk-forward validation.")

        # Minimum training size: 45% of data
        min_train_size = int(N * 0.45)
        test_chunk_size = (N - min_train_size) // self.n_splits

        fold_metrics_list = []
        prediction_rows = []

        for fold in range(self.n_splits):
            train_end = min_train_size + fold * test_chunk_size
            test_start = train_end
            test_end = N if fold == (self.n_splits - 1) else (train_end + test_chunk_size)

            # Purge the last `max_h` bars from training to eliminate overlap with the test set
            purged_train_end = max(10, train_end - self.embargo)

            df_train = df_valid.iloc[:purged_train_end].copy()
            df_test = df_valid.iloc[test_start:test_end].copy()

            if len(df_test) == 0:
                continue

            X_train_all = df_train[all_feature_cols]
            X_test_all = df_test[all_feature_cols]

            X_train_price = df_train[price_only_cols]
            X_test_price = df_test[price_only_cols]

            y_train_returns = {h: df_train[f"target_return_{h}"].values for h in self.horizons}
            base_prices_test = df_test["close"].values

            # Initialize candidate models for this fold
            models: dict[str, BaseMultiHorizonModel] = {
                "NaivePersistence": NaivePersistenceModel(horizons=self.horizons),
                "PriceOnly_Ridge": RidgeSentimentPriceModel(
                    horizons=self.horizons,
                    alpha=2.0,
                    feature_subset=price_only_cols,
                    name="PriceOnly_Ridge"
                ),
                "Ridge_SentimentPrice": RidgeSentimentPriceModel(
                    horizons=self.horizons,
                    alpha=2.0,
                    feature_subset=all_feature_cols,
                    name="Ridge_SentimentPrice"
                ),
                "XGBoost_SentimentPrice": XGBoostMultiHorizonModel(
                    horizons=self.horizons,
                    n_estimators=35,
                    max_depth=3,
                    name="XGBoost_SentimentPrice"
                ),
                "QuantEnsemble": QuantEnsembleModel(horizons=self.horizons),
            }

            for model_name, model in models.items():
                # Fit
                if model_name == "PriceOnly_Ridge":
                    model.fit(X_train_price, y_train_returns)
                    pred_prices_dict = model.predict_prices(X_test_price, base_prices_test)
                    pred_returns_dict = model.predict_returns(X_test_price)
                else:
                    model.fit(X_train_all, y_train_returns)
                    pred_prices_dict = model.predict_prices(X_test_all, base_prices_test)
                    pred_returns_dict = model.predict_returns(X_test_all)

                # Evaluate for each horizon
                for h in self.horizons:
                    actual_p = df_test[f"target_price_{h}"].values
                    pred_p = pred_prices_dict[h]
                    act_r = df_test[f"target_return_{h}"].values
                    prd_r = pred_returns_dict[h]

                    m = compute_metrics(
                        actual_prices=actual_p,
                        predicted_prices=pred_p,
                        base_prices=base_prices_test,
                        actual_returns=act_r,
                        predicted_returns=prd_r,
                        horizon=h,
                    )

                    fold_metrics_list.append({
                        "fold": fold + 1,
                        "model": model_name,
                        "horizon": h,
                        "train_samples": len(df_train),
                        "test_samples": len(df_test),
                        **m,
                    })

                    # Record predictions for each test bar
                    for idx in range(len(df_test)):
                        bar_row = df_test.iloc[idx]
                        prediction_rows.append({
                            "asset": self.config.ticker,
                            "model_name": model_name,
                            "fold": fold + 1,
                            "bar_date": bar_row["date_str"],
                            "horizon": h,
                            "current_price": float(bar_row["close"]),
                            "predicted_price": float(pred_p[idx]),
                            "actual_price": float(actual_p[idx]),
                            "residual": float(pred_p[idx] - actual_p[idx]),
                            "predicted_return": float(prd_r[idx]),
                            "actual_return": float(act_r[idx]),
                        })

        df_metrics_raw = pd.DataFrame(fold_metrics_list)
        df_predictions = pd.DataFrame(prediction_rows)

        # Persist predictions to database
        self.db.save_dataframe(df_predictions, "model_predictions", if_exists="replace")

        # Compute summary table (mean across folds)
        summary_df = (
            df_metrics_raw.groupby(["model", "horizon"])[["mae", "rmse", "mape", "dir_acc", "ic", "rank_ic"]]
            .mean()
            .reset_index()
        )

        print("[WalkForwardValidator] Completed walk-forward validation across all folds.")
        return df_metrics_raw, summary_df, df_predictions

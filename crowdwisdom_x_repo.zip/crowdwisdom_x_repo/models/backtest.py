"""Quantitative backtesting and risk evaluation module.

Computes portfolio performance metrics:
- Annualized Return
- Annualized Volatility
- Sharpe Ratio (Risk-Adjusted Excess Return)
- Sortino Ratio (Downside Risk-Adjusted Return)
- Maximum Drawdown (MDD)
- Calmar Ratio
- Win Rate (%) & Profit Factor
"""

from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from config.settings import Config


class QuantitativeBacktester:
    def __init__(
        self,
        config: Config,
        risk_free_rate_annual: float = 0.04,  # 4% annual risk-free rate
        transaction_cost_bps: float = 5.0,     # 5 bps (0.05%) per trade
    ):
        self.config = config
        self.rf_daily = (1.0 + risk_free_rate_annual) ** (1.0 / 252.0) - 1.0
        self.rf_annual = risk_free_rate_annual
        self.tcost = transaction_cost_bps / 10000.0

    def run_backtest(
        self,
        df_predictions: pd.DataFrame,
        horizon: int = 1,
        threshold: float = 0.0003,  # 3 bps threshold to enter trade
    ) -> tuple[pd.DataFrame, dict[str, dict[str, float]]]:
        """Runs an out-of-sample portfolio backtest on model signals vs Buy & Hold."""
        models = df_predictions["model_name"].unique()
        
        # Sort predictions chronologically
        h_preds = df_predictions[df_predictions["horizon"] == horizon].copy()
        h_preds = h_preds.sort_values("bar_date").reset_index(drop=True)

        unique_dates = sorted(h_preds["bar_date"].unique())
        
        results_by_model = {}
        daily_records = {m: [] for m in models}
        daily_records["Buy_and_Hold"] = []

        # Track dates
        dates_list = []

        for d in unique_dates:
            d_sub = h_preds[h_preds["bar_date"] == d]
            if d_sub.empty:
                continue

            actual_ret = float(d_sub["actual_return"].iloc[0])
            dates_list.append(d)
            daily_records["Buy_and_Hold"].append(actual_ret)

            for m in models:
                m_row = d_sub[d_sub["model_name"] == m]
                if m_row.empty:
                    daily_records[m].append(0.0)
                    continue

                pred_ret = float(m_row["predicted_return"].iloc[0])

                # Position signal: Long (+1), Cash (0), or Short (-1)
                if pred_ret > threshold:
                    pos = 1.0
                elif pred_ret < -threshold:
                    pos = -1.0
                else:
                    pos = 0.0

                # Strategy return with transaction costs on position switches
                strat_ret = pos * actual_ret - (abs(pos) * self.tcost if pos != 0 else 0.0)
                daily_records[m].append(strat_ret)

        # Build equity curves dataframe
        df_equity = pd.DataFrame({"bar_date": dates_list})
        for m in list(models) + ["Buy_and_Hold"]:
            rets = np.array(daily_records[m])
            df_equity[f"ret_{m}"] = rets
            df_equity[f"equity_{m}"] = np.cumprod(1.0 + rets)

            # Compute quantitative risk-adjusted metrics
            metrics = self._calculate_risk_metrics(rets)
            results_by_model[m] = metrics

        return df_equity, results_by_model

    def _calculate_risk_metrics(self, daily_returns: np.ndarray) -> dict[str, float]:
        """Calculates Sharpe, Sortino, Max Drawdown, Calmar, Win Rate, and Profit Factor."""
        rets = np.asarray(daily_returns, dtype=float)
        n = len(rets)
        if n < 2 or np.all(rets == 0) or np.std(rets) < 1e-6:
            return {
                "total_return_pct": 0.0,
                "annualized_return_pct": 0.0,
                "annualized_volatility_pct": 0.0,
                "sharpe_ratio": 0.0,
                "sortino_ratio": 0.0,
                "max_drawdown_pct": 0.0,
                "calmar_ratio": 0.0,
                "win_rate_pct": 0.0,
                "profit_factor": 0.0,
                "n_periods": n,
            }

        total_return = float(np.prod(1.0 + rets) - 1.0)
        ann_return = float(((1.0 + total_return) ** (252.0 / n)) - 1.0) if total_return > -1.0 else -1.0
        ann_vol = float(np.std(rets) * np.sqrt(252))

        # Excess returns
        excess_rets = rets - self.rf_daily
        mean_excess = np.mean(excess_rets)
        std_excess = np.std(excess_rets)

        # 1. Sharpe Ratio
        sharpe = float((mean_excess / (std_excess + 1e-8)) * np.sqrt(252)) if std_excess > 1e-6 else 0.0

        # 2. Sortino Ratio (downside deviation)
        downside_rets = np.minimum(excess_rets, 0.0)
        downside_dev = np.sqrt(np.mean(downside_rets ** 2))
        sortino = float((mean_excess / (downside_dev + 1e-8)) * np.sqrt(252)) if downside_dev > 1e-6 else 0.0

        # 3. Maximum Drawdown
        equity_curve = np.cumprod(1.0 + rets)
        running_max = np.maximum.accumulate(equity_curve)
        drawdowns = (equity_curve - running_max) / running_max
        max_drawdown = float(np.min(drawdowns))  # Negative number

        # 4. Calmar Ratio
        calmar = float(ann_return / (abs(max_drawdown) + 1e-8)) if max_drawdown < 0 else 0.0

        # 5. Win Rate & Profit Factor
        trade_rets = rets[rets != 0]
        n_trades = len(trade_rets)
        if n_trades > 0:
            win_rate = float(np.sum(trade_rets > 0) / n_trades * 100.0)
            gains = float(np.sum(trade_rets[trade_rets > 0]))
            losses = float(np.abs(np.sum(trade_rets[trade_rets < 0])))
            profit_factor = float(gains / (losses + 1e-8)) if losses > 0 else 99.0
        else:
            win_rate, profit_factor = 0.0, 0.0

        return {
            "total_return_pct": round(total_return * 100.0, 2),
            "annualized_return_pct": round(ann_return * 100.0, 2),
            "annualized_volatility_pct": round(ann_vol * 100.0, 2),
            "sharpe_ratio": round(sharpe, 3),
            "sortino_ratio": round(sortino, 3),
            "max_drawdown_pct": round(max_drawdown * 100.0, 2),
            "calmar_ratio": round(calmar, 3),
            "win_rate_pct": round(win_rate, 2),
            "profit_factor": round(profit_factor, 2),
            "n_periods": n,
        }

    def plot_backtest_equity_curves(self, df_equity: pd.DataFrame) -> Path:
        """Plots cumulative equity curves comparing models vs Buy & Hold."""
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=(13, 8), sharex=True, gridspec_kw={"height_ratios": [3, 1]}
        )

        dates = pd.to_datetime(df_equity["bar_date"])

        # Models to plot
        palette = {
            "QuantEnsemble": "#2ecc71",
            "XGBoost_SentimentPrice": "#e74c3c",
            "Ridge_SentimentPrice": "#9b59b6",
            "PriceOnly_Ridge": "#3498db",
            "Buy_and_Hold": "#7f8c8d",
        }

        for col, color in palette.items():
            eq_col = f"equity_{col}"
            if eq_col in df_equity.columns:
                linewidth = 2.5 if col in ["QuantEnsemble", "Buy_and_Hold"] else 1.5
                linestyle = "--" if col == "Buy_and_Hold" else "-"
                ax1.plot(
                    dates,
                    df_equity[eq_col],
                    label=col.replace("_", " "),
                    color=color,
                    linewidth=linewidth,
                    linestyle=linestyle,
                )

        ax1.axhline(1.0, color="black", linestyle=":", alpha=0.5)
        ax1.set_ylabel("Growth of $1.00 Investment", fontsize=11, fontweight="bold")
        ax1.set_title(
            f"CrowdWisdomTrading: Out-of-Sample Quantitative Backtest ({self.config.ticker})",
            fontsize=13,
            fontweight="bold",
            pad=12,
        )
        ax1.legend(loc="upper left", framealpha=0.9)
        ax1.grid(True, linestyle="--", alpha=0.5)

        # Drawdown Subplot for Best Model vs Buy & Hold
        for col, color in [("QuantEnsemble", "#2ecc71"), ("Buy_and_Hold", "#7f8c8d")]:
            eq_col = f"equity_{col}"
            if eq_col in df_equity.columns:
                curve = df_equity[eq_col].values
                peak = np.maximum.accumulate(curve)
                dd = (curve - peak) / peak * 100.0
                ax2.plot(dates, dd, label=f"{col} DD", color=color, linewidth=1.5)
                ax2.fill_between(dates, dd, 0, color=color, alpha=0.15)

        ax2.set_ylabel("Drawdown (%)", fontsize=10, fontweight="bold")
        ax2.set_xlabel("Date", fontsize=11, fontweight="bold")
        ax2.legend(loc="lower left", fontsize=8)
        ax2.grid(True, linestyle="--", alpha=0.5)

        plt.tight_layout()
        out_path = self.config.charts_dir / "visual_matrix_strategy_backtest.png"
        fig.savefig(out_path, dpi=300)
        plt.close(fig)
        return out_path

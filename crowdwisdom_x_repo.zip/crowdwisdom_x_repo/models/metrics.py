"""Evaluation metrics for multi-horizon price and return forecasting."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, pearsonr


def compute_metrics(
    actual_prices: np.ndarray | pd.Series,
    predicted_prices: np.ndarray | pd.Series,
    base_prices: np.ndarray | pd.Series,
    actual_returns: np.ndarray | pd.Series | None = None,
    predicted_returns: np.ndarray | pd.Series | None = None,
    horizon: int = 1,
) -> dict[str, float]:
    """Computes comprehensive quantitative performance metrics."""
    actual_p = np.asarray(actual_prices, dtype=float)
    pred_p = np.asarray(predicted_prices, dtype=float)
    base_p = np.asarray(base_prices, dtype=float)

    # Filter out NaNs if any
    mask = ~(np.isnan(actual_p) | np.isnan(pred_p) | np.isnan(base_p))
    if np.sum(mask) == 0:
        return {"mae": np.nan, "rmse": np.nan, "mape": np.nan, "dir_acc": np.nan, "ic": np.nan, "rank_ic": np.nan}

    actual_p = actual_p[mask]
    pred_p = pred_p[mask]
    base_p = base_p[mask]

    # Price errors
    abs_errors = np.abs(pred_p - actual_p)
    mae = float(np.mean(abs_errors))
    rmse = float(np.sqrt(np.mean((pred_p - actual_p) ** 2)))
    mape = float(np.mean(abs_errors / np.maximum(actual_p, 1e-6)) * 100.0)

    # Directional accuracy
    if horizon == 0:
        # At horizon 0, price is nowcast at anchor
        dir_acc = 100.0
    else:
        true_dir = np.sign(actual_p - base_p)
        pred_dir = np.sign(pred_p - base_p)
        correct_dir = (true_dir == pred_dir)
        dir_acc = float(np.mean(correct_dir) * 100.0)

    # Information Coefficient (IC) on returns
    if actual_returns is not None and predicted_returns is not None:
        act_r = np.asarray(actual_returns, dtype=float)[mask]
        prd_r = np.asarray(predicted_returns, dtype=float)[mask]
    else:
        act_r = (actual_p - base_p) / base_p
        prd_r = (pred_p - base_p) / base_p

    if len(act_r) > 2 and np.std(act_r) > 1e-8 and np.std(prd_r) > 1e-8:
        ic, _ = pearsonr(prd_r, act_r)
        rank_ic, _ = spearmanr(prd_r, act_r)
    else:
        ic, rank_ic = 0.0, 0.0

    return {
        "mae": round(mae, 4),
        "rmse": round(rmse, 4),
        "mape": round(mape, 4),
        "dir_acc": round(dir_acc, 2),
        "ic": round(float(ic), 4),
        "rank_ic": round(float(rank_ic), 4),
    }
